﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Resto.Models
{
    public class SectionViewModel
    {
        public SectionViewModel()
        {
        }

        

        public List<Section> Sections { get; set; }
    }
}