﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Resto.Models
{
    public class Produit
    {
        public string Nom { get; set; }
        public double Prix { get; set; }

        public Produit(){ }
    }
}